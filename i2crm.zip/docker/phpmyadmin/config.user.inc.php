<?php
$cfg['VersionCheck'] = false;
$cfg['DefaultCharset'] = 'utf8';
$cfg['DefaultConnectionCollation'] = 'utf8_unicode_ci';
